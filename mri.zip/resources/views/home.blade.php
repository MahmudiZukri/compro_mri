<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>MRI</title>

        <!-- Fonts -->
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <link href="{{ asset('fonts/circular-std/font.css') }}" rel="stylesheet">
        <!-- Styles -->


        <style>
        </style>
    </head>
    <body class="overflow-x-hidden">
        <div id="home1" class="relative bg-gradient-to-br from-[#FE4ECD] from-0% via-[#C564CB] via-100% h-screen w-screen z-[100px]">
            @include('partials.nav')
            <div class="absolute left-0 translate-x-[-23rem] top-0 translate-y-[-15rem] 2xl:h-[32rem] 2xl:w-[32rem]">
                <img src="assets/patterns/circle.svg" class="w-full" alt="">
            </div>
            <div class="w-5/12 absolute left-16 top-[16rem]">
                <h1 class="font-bold font-circularStd text-xl 2xl:text-3xl 3xl:text-7xl text-white 2xl:leading-12 3xl:leading-24">We help you maintaining your health and <br>
                    find the best solution
                </h1>
            </div>
            <div class="absolute right-0 bottom-[0px] z-10">
                <img src="{{ asset('assets/images/doctor.png')}}" class="xl:w-[38rem]" alt="">
            </div>
            <div class="absolute right-0 bottom-0 xl:h-[40rem] 2xl:h-[40rem] xl:w-[40rem] 2xl:w-[40rem] ">
                <img src="assets/patterns/circle.svg" class="w-full ml-[10rem]
                mt-[10rem]" alt="">
            </div>
            <div class="absolute bottom-[-4rem] left-[12rem] origin-top-left rotate-24">
                <img src="assets/patterns/shapes2.svg" class="2xl:w-[65rem] 3xl:w-[80rem]" alt="">
            </div>
        </div>
        <div id="home2 " class="relative bg-gradient-to-r from-[#FFF0FA] from-5% via-[#FEE6F4] via-100%  h-[3664px]">

           @include('partials.nav')
            <div class="relative flex justify-center items-center h-screen ">
                <div class="absolute left-0">
                    <img src="assets/patterns/Syringe.svg" class="w-full" alt="">
                </div>
                <div class="w-4/12">
                    <h1 class="text-center font-bold font-circularStd text-7xl text-bold leading-24 mb-16">
                        Get to know
                        MRI Products
                    </h1>
                    <div class="relative">
                        <img src="assets/patterns/star.svg" class="absolute top-[-20px] left-[-30px] w-18" alt="">
                        <button class="w-full py-8 rounded-full text-white font-bold text-xl bg-gradient-to-b from-[#FF00B8] from-5% via-[#C564CB] via-100% rounded-10">Explore</button>
                        <img src="assets/patterns/star.svg" class="absolute bottom-[-20px] right-[-20px] w-18" alt="">
                    </div>

                </div>
                <div class="absolute right-0 w-[460px] h-[460px] translate-y-2 translate-x-2/4">
                    <img src="assets/patterns/circle-2.svg" class="" alt="">
                </div>
            </div>
            <div class="relative h-screen mx-auto w-screen flex justify-center bg-[url('/assets/patterns/bg-lulu.svg')] bg-center bg-no-repeat">
                <div class="w-5/12 text-center">
                    <h1 class="font-bold text-7xl mb-36">Lulu.id</h1>
                    <p class="text-xl font-medium">Lulu.id Beauty Clinic <span class="font-book">is dedicated to delivering high-quality facial and <br> body treatments, ensuring that every individual receives the <br> appropriate and top-notch beauty care they deserve.</span></p>
                    <div class="flex mt-16">
                        <div class="translate-y-[-0.8rem] origin-bottom -rotate-12 z-10">
                            <img src="assets/lulu1.png" class="border-4 rounded-3xl border-white" alt="">
                        </div>
                        <div class="translate-x-[-0.5rem] origin-top-left rotate-12 z-20">
                            <img src="assets/lulu2.png" class="border-4 rounded-3xl border-white" alt="">
                        </div>
                        <div class="translate-x-[-2rem] translate-y-[-1rem] origin-bottom -rotate-12 z-30">
                            <img src="assets/lulu3.png" class="border-4 rounded-3xl border-white" alt="">
                        </div>
                    </div>
                </div>
                <div class="absolute left-[6rem] bottom-[6rem] paginate flex flex-wrap ">
                    <div class="grid grid-cols-3 gap-2">
                    <div class="w-12 h-12 flex justify-center items-center bg-[#FF00B8] rounded-full">
                        <a href="" class=" text-white font-medium text-xl">1</a>
                    </div>
                    <div class="w-12 h-12 flex justify-center items-center ">
                        <a href="" class=" text-black font-medium text-xl">2</a>
                    </div>
                    <div class="w-12 h-12 flex justify-center items-center ">
                        <a href="" class=" text-black font-medium text-xl">3</a>
                    </div>
                    </div>
                </div>
            </div>
            <div class="h-screen relative w-screen flex flex-row px-24 bg-[url('/assets/patterns/bg-lulu.svg')] bg-center bg-no-repeat">
                <div class="absolute left-[10%]">
                    <img src="assets/patterns/circle2.svg" alt="">
                </div>
                <div class="mt-16">
                    <h1 class="font-bold text-7xl mb-16">Silium.id</h1>
                    <p class="font-book text-2xl">Silium.id is a beauty studio that specializes in nail, <br> eyelash, and eyebrow treatments. We are dedicated <br> to providing high-quality care using the latest <br> products and techniques, and have a team of experts <br> who provide the right solutions.</p>
                </div>
                <div class="absolute right-[10%]">
                    <img src="assets/patterns/price-tag.svg" class="w-[700px]" alt="">
                </div>
                <div class="absolute left-[6rem] bottom-[6rem] paginate flex flex-wrap ">
                    <div class="grid grid-cols-3 gap-2">
                        <div class="w-12 h-12 flex justify-center items-center bg-[#FF00B8] rounded-full">
                            <a href="" class=" text-white font-medium text-xl">1</a>
                        </div>
                        <div class="w-12 h-12 flex justify-center items-center ">
                            <a href="" class=" text-black font-medium text-xl">2</a>
                        </div>
                        <div class="w-12 h-12 flex justify-center items-center ">
                            <a href="" class=" text-black font-medium text-xl">3</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="h-screen bg-red-300 relative w-screen flex justify-center z-[100px] flex-row bg-[url('/assets/patterns/bg-lulu.svg')] bg-center bg-no-repeat">
                <div class="absolute bottom-[-5rem] w-[520px] flex flex-row justify-center">
                    <img src="assets/patterns/lunoar.svg" class="" alt="">
                </div>
                <div class="w-6/12 text-center mt-16">
                    <h1 class="font-bold text-7xl mb-16">Lunoar.id</h1>
                    <p class="font-book text-2xl">Lunoar is our beauty product that provides the best protection and  nutrition for the skin, as well as providing natural hydration, firmness,  and brightening to the face.</p>
                </div>
                <div class="absolute right-[-10rem] translate-y-[2rem] z-0 w-[550px] h-[550px]">
                    <img src="assets/patterns/circle-2.svg" class="" alt="">
                </div>
                <div class="absolute left-[6rem] bottom-[6rem] paginate flex flex-wrap ">
                    <div class="grid grid-cols-3 gap-2">
                        <div class="w-12 h-12 flex justify-center items-center bg-[#FF00B8] rounded-full">
                            <a href="" class=" text-white font-medium text-xl">1</a>
                        </div>
                        <div class="w-12 h-12 flex justify-center items-center ">
                            <a href="" class=" text-black font-medium text-xl">2</a>
                        </div>
                        <div class="w-12 h-12 flex justify-center items-center ">
                            <a href="" class=" text-black font-medium text-xl">3</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="relative w-screen bg-blue-500 h-[1508px] z-[50px] ">
                <div class="absolute top-[-10rem] left-[25rem]  w-[400px]">
                    <img src="assets/jarum.svg" class="z-0" alt="">
                </div>
                <div class="absolute top-[10rem] right-0 w-[400px]">
                    <img src="assets/tetoskop.svg" class="z-0" alt="">
                </div>
                <div class="absolute top-[10rem] left-0 w-[400px]">
                    <img src="assets/tas.svg" class="z-0" alt="">
                </div>
                <div class="flex justify-center items-center ">
                    <div class="w-10/12 text-center mt-[16rem]">
                        <h1 class="2xl:text-6xl 3xl:text-7xl font-bold text-white mb-16">Meet Our Doctor</h1>
                        <p class="font-book text-white 2xl:text-xl">Our doctor is certified for giving the best treatment</p>
                    </div>
                </div>
                <div class="absolute bottom-[-4rem] right-0 w-[60rem] ">
                    <img src="assets/patterns/bg-lulu.svg" alt="">
                </div>
            </div>
        </div>
        <div id="home3" class="relative bg-[#FFCBEE] w-screen h-screen  flex items-center mx-auto bg-black-400">
        @include('partials.nav')
            <div class="flex flex-row justify-between items-center px-16 w-screen bg-[url('/assets/patterns/bg-lulu.svg')] bg-no-repeat bg-center bg-contain">

                <div class="w-5/12">
                    <h1 class="font-bold mb-8 text-7xl text-left">Let’s start to build
                        future <span class="text-[#F84FDD]">with us</span>
                    </h1>
                    <button class="py-6 text-2xl bg-[#FF00B8] font-bold text-white rounded-full w-7/12">
                        Contact Us
                    </button>
                </div>
                <div class="w-[500px] ">
                    <img src="assets/salaman.svg" class="origin-top-left rotate-12" alt="">
                </div>
            </div>
        </div>
        <script src="js/nav.js"></script>
    </body>
</html>
