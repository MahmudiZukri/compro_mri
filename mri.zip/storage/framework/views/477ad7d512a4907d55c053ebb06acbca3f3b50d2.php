
<header class="bg-transparent absolute top-0 w-screen flex flex-wrap items-center justify-between mx-auto p-4">
    <nav class="
    w-screen">
        <div class="flex flex-wrap items-center justify-between mx-auto p-4">
            <a href="" class="flex items-center">
                <span class="self-center text-logo text-2xl font-circularstd font-bold whitespace-nowrap
                <?php echo e(Request::is('/') ? 'text-white' : ''); ?>">MRI.id</span>
            </a>

            <div class="hidden w-full md:block md:w-auto" id="navbar-default">
            <ul class="font-circularstd font-medium flex flex-col p-4 md:p-0 mt-4  md:flex-row md:space-x-8 md:mt-0 md:border-0">
                <li class="<?php echo e(Request::is('/') ? 'font-bold text-white/50' : 'text-[#F84FDD]'); ?> ">
                    <a href="<?php echo e(url('/')); ?>" >Home</a>
                </li>
                <li>
                    <a href="<?php echo e(url('vision')); ?>" class="<?php echo e(Request::is('/') ? 'text-white/50' : 'text-[#F84FDD]'); ?>">Our Vision</a>
                </li>
                <li>
                    <a href="<?php echo e(url('traction')); ?>" class="<?php echo e(Request::is('/') ? 'text-white/50' : 'text-[#F84FDD]'); ?>">Our Traction</a>
                </li>
                <li>
                    <a href="<?php echo e(url('gallery')); ?>" class="<?php echo e(Request::is('/') ? 'text-white/50' : 'text-[#F84FDD]'); ?>">Gallery</a>
                </li>
                <li>
                    <a href="<?php echo e(url('aboutus')); ?>" class="<?php echo e(Request::is('/') ? 'text-white/50' : 'text-[#F84FDD]'); ?>">About Us</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>
</header>



<?php /**PATH E:\RAKSASA\mri\resources\views/partials/nav.blade.php ENDPATH**/ ?>