<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>MRI</title>

        <!-- Fonts -->
        <link href="<?php echo e(asset('css/font.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <!-- Styles -->
       

        <style>
        </style>
    </head>
    <body class="overflow-x-hidden">
        <div id="home1" class="relative bg-gradient-to-r from-[#FF00B8] from-5% via-[#C564CB] via-100% h-screen w-screen z-[100px]">
            <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
            <div class="absolute left-[-370px] top-[-20%] h-[500px] w-[500px]">
                <img src="assets/patterns/circle.svg" class="w-full" alt="">
            </div>
            <div class="w-5/12 absolute left-16 top-[36%]">
                <h1 class="font-bold font-circularstd text-7xl text-white leading-24">We help you maintaining your health and <br>
                    find the best solution
                </h1>
            </div>
            <div class="absolute right-0 bottom-[0px] z-10">
                <img src="<?php echo e(asset('assets/images/doctor.png')); ?>" class="w-[800px]" alt="">  
            </div>
            <div class="absolute right-0 bottom-0 h-[800px] w-[800px] ">
                <img src="assets/patterns/circle.svg" class="w-full ml-[30%]
                mt-[30%]" alt="">
            </div>
            <div class="absolute bottom-[-5%] left-[12%] origin-top-left rotate-24">
                <img src="assets/patterns/shapes2.svg" class="w-[1420px]" alt="">
            </div>  
        </div>
        <div id="home2 " class="relative bg-gradient-to-b from-[#FFF0FA] from-5% via-[#FEE6F4] via-100%  h-[3664px] px-36">

            
            <div class="relative flex justify-center w-screen align-middle h-screen ">
                <div class="absolute left-0">
                    <img src="assets/patterns/Syringe.svg" class="w-[700px]" alt="">
                </div>
                <div class="h-screen flex items-center ">
                    <div>
                        <div class="">
                            <h1 class="text-center font-bold font-circularstd text-7xl text-bold leading-24 mb-16">
                                Get to know <br>
                                MRI Products
                            </h1>
                        </div>
                        <div class="relative">
                            <img src="assets/patterns/star.svg" class="absolute top-[-20px] left-[-30px] w-18" alt="">
                            <button class="w-full py-8 rounded-full text-white font-bold text-xl bg-gradient-to-b from-[#FF00B8] from-5% via-[#C564CB] via-100% rounded-10">Explore</button>
                            <img src="assets/patterns/star.svg" class="absolute bottom-[-20px] right-[-20px] w-18" alt="">
                        </div>
                    </div>
                </div>
                <div class="absolute right-0 w-[460px] h-[460px] translate-y-2/4">
                    <img src="assets/patterns/circle-2.svg" class="" alt="">
                </div>
            </div>
            <div class="h-screen mx-auto w-screen flex justify-center bg-[url('/assets/patterns/bg-lulu.svg')] bg-center bg-no-repeat">
                <div class="w-5/12 text-center">

                    <h1 class="font-bold text-7xl mb-16">Lulu.id</h1>
                    <p class="text-xl font-medium">Lulu.id Beauty Clinic <span class="font-book">is dedicated to delivering high-quality facial and <br> body treatments, ensuring that every individual receives the <br> appropriate and top-notch beauty care they deserve.</span></p>
                </div>
            </div>
            <div class="h-screen relative w-screen flex flex-row  bg-[url('/assets/patterns/bg-lulu.svg')] bg-center bg-no-repeat">
                <div class="absolute left-[10%]">
                    <img src="assets/patterns/circle2.svg" alt="">
                </div>
                <div class="mt-16">
                    <h1 class="font-bold text-7xl mb-16">Silium.id</h1>
                    <p class="font-book text-2xl">Silium.id is a beauty studio that specializes in nail, <br> eyelash, and eyebrow treatments. We are dedicated <br> to providing high-quality care using the latest <br> products and techniques, and have a team of experts <br> who provide the right solutions.</p>
                </div>
                <div class="absolute right-[10%]">
                    <img src="assets/patterns/price-tag.svg" class="w-[700px]" alt="">
                </div>
            </div>
            <div class="h-screen relative w-screen flex justify-center flex-row bg-[url('/assets/patterns/bg-lulu.svg')] bg-center bg-no-repeat">
                <div class="flex justify-center">
                    <img src="assets/patterns/lunoar.svg" alt="">
                </div>
                <div class="mt-16 text-center">
                    <h1 class="font-bold text-7xl mb-16">Lunoar.id</h1>
                    <p class="font-book text-2xl">Lunoar is our beauty product that provides the best protection and <br> nutrition for the skin, as well as providing natural hydration, firmness, <br> and brightening to the face.</p>
                </div>
                <div class="absolute right-[10%]">
                    <img src="assets/patterns/circle-2.svg" class="w-[700px]" alt="">
                </div>
            </div>
        </div>
        
        
        
    </body>
</html>
<?php /**PATH D:\compro\mri\resources\views/home.blade.php ENDPATH**/ ?>